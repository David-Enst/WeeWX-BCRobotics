## weewx-BCRobotics
##
## Installation for WeeWX V5

1) Install weewx, select Simulator as the weather station

http://weewx.com/docs/usersguide.htm

2) Install the driver

weectl extension install https://github.com/David-Enst/WeeWX-BCRobotics/blob/master/bin/user/driver.zip

3) Configure the driver

weectl station create --driver='weewx.drivers.bcrobotics'

4) Restart weewx

sudo systemctl start weewx
